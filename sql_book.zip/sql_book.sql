SELECT * FROM rohith.customers;

SELECT SALARY FROM rohith.customers;
SELECT AGE FROM rohith.customers;
SELECT * FROM rohith.customers WHERE SALARY > 300000;
SELECT * FROM rohith.customers WHERE SALARY IN (300000, 450000);
SELECT * FROM rohith.customers WHERE AGE >27 AND SALARY > 350000;
SELECT * FROM rohith.customers WHERE EXP BETWEEN 2 AND 4;
SELECT * FROM rohith.customers WHERE SALARY > 325000 OR EXP < 3;
SELECT * FROM rohith.customers WHERE SALARY = 400000 AND NAME = 'Tony';

SELECT * FROM rohith.customers WHERE NAME LIKE('%on%');
SELECT * FROM rohith.customers WHERE NAME LIKE('%as');
SELECT * FROM rohith.customers WHERE NAME LIKE('_as');
SELECT * FROM rohith.customers WHERE AGE is not null;
SELECT * FROM rohith.customers WHERE SALARY is not null;
UPDATE rohith.customers SET NAME = 'Nick' WHERE  id = 1;
UPDATE rohith.customers SET ADDRESS = 'Delhi' WHERE  id = 1;
SELECT * FROM rohith.customers;
SELECT * FROM rohith.employe;
SELECT ID,NAME,SALARY,COMPANY,DOMAIN FROM rohith.customers,rohith.employe WHERE rohith.customers.ID = rohith.employe.EMPLOYE_ID;
# NOW WE ARE USING JOINS
SELECT * FROM rohith.customers INNER JOIN rohith.employe ON rohith.customers.ID = rohith.employe.EMPLOYE_ID;
SELECT * FROM rohith.customers LEFT JOIN rohith.employe ON rohith.customers.ID = rohith.employe.EMPLOYE_ID;
SELECT * FROM rohith.customers RIGHT JOIN rohith.employe ON rohith.customers.ID = rohith.employe.EMPLOYE_ID;
SELECT * FROM rohith.customers LEFT JOIN rohith.employe ON rohith.customers.ID = rohith.employe.EMPLOYE_ID
 UNION
 SELECT * FROM rohith.customers RIGHT JOIN rohith.employe ON rohith.customers.ID = rohith.employe.EMPLOYE_ID;
SELECT rohith.customers.NAME,rohith.employe.COMPANY FROM rohith.customers FULL JOIN rohith.employe ON rohith.customers.ID = rohith.employe.EMPLOYE_ID;
SELECT rohith.customers.NAME AS EMPLOYE_NAME,
        rohith.employe.DOMAIN AS EMPLOYE_DOMAIN
FROM rohith.customers
   CROSS JOIN rohith.employe;
select * from rohith.customers;
select * from rohith.employe;
SELECT * FROM rohith.customers AS C, rohith.employe AS E WHERE C.ID = E.EMPLOYE_ID;
SELECT ID AS EMPLOYE_ID, NAME AS EMPLOYE_NAME FROM rohith.customers WHERE SALARY IS NOT NULL;
